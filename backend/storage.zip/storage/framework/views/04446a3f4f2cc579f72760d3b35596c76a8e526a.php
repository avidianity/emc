<?php $__env->startComponent('mail::message'); ?>
# Hi <?php echo e($user->first_name); ?>.

Here are your account credentials<br />
Account Number: <b><?php echo e($user->uuid); ?></b><br />
<p id="password">Password: <b><?php echo e($user->password); ?></b></p>

Please use these crendentials to login to the system.

Thanks,<br />
<?php echo e(isset($name) ? $name : config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\manlu\Desktop\Projects\emc\backend\resources\views/emails/account.blade.php ENDPATH**/ ?>