<?php $__env->startComponent('mail::message'); ?>
# Hi <?php echo e($student->first_name); ?>.

<p>You have been admitted to Course: <?php echo e($admission->course->code); ?> - <?php echo e($admission->level); ?> Year of <?php echo e($admission->term); ?>.</p>

<b>Here is your user account credentials</b>
<p>Account No.: <?php echo e($student->uuid); ?></p>
<p id="password">Password: <?php echo e($student->password); ?></p>
<br />
<p>Please use this credentials to login to the system.</p>

Thanks,<br />
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/avidian/Development/emc/new/backend/resources/views/emails/pre-registration.blade.php ENDPATH**/ ?>