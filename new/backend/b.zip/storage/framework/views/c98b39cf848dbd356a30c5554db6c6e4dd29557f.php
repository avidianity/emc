<?php echo e($slot); ?>

<?php /**PATH /home/avidian/Development/emc/new/backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>