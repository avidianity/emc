<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	<meta name="theme-color" content="#000000" />

	<title>EMC</title>
	<meta name="title" content="EMC">
	<meta name="description" content="EMC">
	<link rel="stylesheet" href="<?= asset('app-css/bootstrap.css') ?>" />
	<link rel="stylesheet" href="<?= asset('app-css/owl.theme.css') ?>" />
	<link rel="stylesheet" href="<?= asset('app-css/owl.carousel.css') ?>" />
	<link rel="stylesheet" href="<?= asset('app-css/landing.css') ?>" />
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600" rel="stylesheet" type="text/css">
</head>

<body>