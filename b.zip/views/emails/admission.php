<div>
	<p>Hi $name,</p>

	<p>You have been admitted to Course: $course_code - $level Year of $term.</p>

	<b>Here is your user account credentials</b>
	<p>Account No.: $number</p>
	<p>Password: $password</p>
	<br />
	<p>Please use this credentials to login to the system.</p>
	<p>Thank You</p>

	<p>
		$registrar_name,
		Registrar
	</p>
</div>