<?php extend('dashboard.layouts.top') ?>
<?php extend('dashboard.analytics.students') ?>
<?php extend('dashboard.layouts.bottom') ?>