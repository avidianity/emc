<?php extend('layouts.header') ?>
<div class="wrapper">
	<?php extend('dashboard.layouts.navbar') ?>
	<?php extend('dashboard.layouts.sidebar') ?>
	<main role="main" class="main-content">