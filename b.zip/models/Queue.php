<?php

namespace Models;

class Queue extends Model
{
	protected $fillable = ['payload'];
}
